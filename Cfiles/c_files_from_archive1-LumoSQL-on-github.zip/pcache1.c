
void sqlite3PCacheSetDefault(void){}
void sqlite3PCacheBufferSetup(void *pBuf, int sz, int n){}
