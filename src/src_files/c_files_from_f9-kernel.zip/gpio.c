/* no additional platform specific implementation */
