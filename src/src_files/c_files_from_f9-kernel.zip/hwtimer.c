/* no additional platform specific implementation */

/* No Unshareable code temporary */
