#include<stdio.h>
int main()  //main function
{
  int a,b;
  
   printf("Enter first number:\n");
  scanf ("%d",&a);
  printf("Enter second number:\n");
  scanf ("%d",&b);
  
  printf("Addition of two numbers = %d",a+b);
  return 0;
}
