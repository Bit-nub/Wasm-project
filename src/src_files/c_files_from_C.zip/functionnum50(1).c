//C program to print numbers from 1 to 50 using function.

#include<stdio.h>
int num(int i);
void main()
{
    int i;
     int t=num(i);
}
int num(int i)
{
  for(i=1;i<=50;i++)
  printf("%d\t",i);
}
