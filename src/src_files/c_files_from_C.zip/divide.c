//C program to divide two numbers.

#include<stdio.h>
int main()
{
  float n1,n2,div;
  printf("Enter two numbers:");// Take input from user
  scanf("%f%f",&n1,&n2);
  div=n1/n2; // for divide users number
  printf("Division of two numbers=%.3f",div);// give output of the users input
}
