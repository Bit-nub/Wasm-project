//C program to print 50 natural numbers using do-while loop.

#include<stdio.h>
int main()
{  int i=1;
do{
     printf("%d\t",i);
     i++;
  } while(i<=50);
}

