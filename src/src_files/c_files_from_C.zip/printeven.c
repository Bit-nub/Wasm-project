//C program to print only even numbers between 0 to 50.

#include<stdio.h>
int main()
{ int i;
for(i=2;i<=50;i+=2)
  printf("%d\t",i);
}
