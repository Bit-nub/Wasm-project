//C program to print first 50 natural numbers.

#include<stdio.h>
int main()
{ int i;
for(i=1;i<=50;i++)
    printf("%d\t",i);
}

