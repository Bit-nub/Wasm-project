int main()
{
static long long a[1024 * 1024 * 20] = { 0 };

return a;

}