#include "clib-settings.h"

const char *manifest_names[] = {"clib.json", "package.json", 0};
