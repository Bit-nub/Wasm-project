#include <stdio.h>
int main()
{
    printf("Hello, world!");
	printf("\n");
	return 0;
}

#ifndef __NO_SYSTEM_INIT
void SystemInit()
{}
#endif
