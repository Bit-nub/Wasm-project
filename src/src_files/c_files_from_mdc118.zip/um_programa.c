/* inclusão de bibliotecas externas */
#include <stdio.h> // "stdio.h" possui funções básicas de entrada/saída
                   // acesse https://www.tutorialspoint.com/c_standard_library/index.htm
                   // para ver a relação de bibliotecas padrão do C

/* função principal do programa */
int main()
{
    /* seu código aqui */

    return 0; // valor retornado após execução do programa
}