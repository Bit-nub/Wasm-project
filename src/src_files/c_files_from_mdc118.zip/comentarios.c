#include <stdio.h>

/* 
   Funcão main()
   retorna um inteiro   
   (exemplo de comentário de bloco)
 */
int main()
{
    printf("passei aqui...\n"); // imprime passei aqui... (exemplo de comentário de linha)

    // uma linha de código comentada não será compilada
    // printf("passei aqui de novo...\n");

    return 0;
}