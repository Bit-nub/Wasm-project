extern int v7_example(void);

int main(void) {
  return v7_example();
}
