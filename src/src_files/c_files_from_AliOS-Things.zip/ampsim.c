#include <stdio.h>
#include <stdlib.h>

extern int amp_main(void);
int main(int argc, char **argv)
{
    amp_main();
    return 0;
}