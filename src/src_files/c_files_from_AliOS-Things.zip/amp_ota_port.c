void internal_sys_upgrade_start(void *ctx)
{
    return;
}
