#include <stdio.h>
#include <stdint.h>

unsigned int g_ntp_time = 0;
unsigned int g_up_time = 0;

int app_management_center_init()
{
    return 0;
}

int amp_boot_main()
{
    return 0;
}

int amp_recovery_init()
{
    return 0;
}

void amp_recovery_entry()
{
}

void amp_app_version_set()
{
}
