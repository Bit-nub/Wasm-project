/*
 * Copyright (C) 2015-2020 Alibaba Group Holding Limited
 */

#include <stdio.h>
#include <stdarg.h>

extern int amp_main();

int main(void)
{
    amp_main();
}
