#include <netdb.h>

struct servent *getservbyname(const char *name, const char *proto) {
	return NULL;
}
