// Copyright 2022 Tomek (@m40-dev)
// SPDX-License-Identifier: GPL-2.0-or-later

#include "5x5_macropad.h"