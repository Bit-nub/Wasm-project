// Copyright 2021 Evelien Dekkers (@evyd13)
// SPDX-License-Identifier: GPL-2.0-or-later

#include "aves60.h"
