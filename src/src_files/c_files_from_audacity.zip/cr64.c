/* SoX Resampler Library      Copyright (c) 2007-16 robs@users.sourceforge.net
 * Licence for this file: LGPL v2.1                  See LICENCE for details. */

#define RATE_CB    _soxr_rate64_cb
#define CORE_STR   "cr64"

#define CORE_TYPE  CORE_DBL
#include "cr-core.c"
