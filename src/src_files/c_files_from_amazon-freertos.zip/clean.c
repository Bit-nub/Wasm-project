int main( void )
{
    int lFoo = 0;

    return lFoo;
}
