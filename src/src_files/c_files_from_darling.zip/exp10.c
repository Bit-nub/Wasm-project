extern double pow(double b, double p);
extern float powf(float b, float p);

double __exp10(double x) {
	return pow(10, x);
};

float __exp10f(float x) {
	return pow(10, x);
};
