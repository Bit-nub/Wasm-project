int abs(int v)
{
	if (v < 0)
		return -v;
	else
		return v;
}

