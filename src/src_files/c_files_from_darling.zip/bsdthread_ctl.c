#include "bsdthread_ctl.h"

long sys_bsdthread_ctl(long command, void* arg1, void* arg2, void* arg3) {
	return 0;
};
