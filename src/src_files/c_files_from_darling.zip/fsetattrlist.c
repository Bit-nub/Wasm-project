#include "fsetattrlist.h"

#define HAS_PATH 0
#define FUNC_NAME sys_fsetattrlist

#include "setattrlist_generic.c"
