const void *const __dso_handle __attribute__ ((__visibility__ ("hidden"))) = &__dso_handle;

