int acl_copy_int_native()
{
	return 0;
}

int acl_size()
{
	return 0;
}
