void* kSZArchiverOptionNoCentralDirectory;
void* kSZArchiverOptionNoSeekOutput;


