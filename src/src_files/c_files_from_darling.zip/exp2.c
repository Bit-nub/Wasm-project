/*
 *  exp2.c
 *  cLibm
 *
 *  Created by Ian Ollmann on 6/14/07.
 *  Copyright 2007 Apple Inc. All rights reserved.
 *
 */
 
 #include <math.h>
 
 #warning exp2 is just a stub to get the test linking
 
 double exp2( double x )
 {
 
	return 0.0;
 }

