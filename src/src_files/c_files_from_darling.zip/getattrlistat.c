#include "getattrlistat.h"

#define HAS_PATH 1
#define FUNC_NAME sys_getattrlistat

#include "getattrlist_generic.c"
