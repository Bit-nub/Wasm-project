#include "iopolicysys.h"
#include "../base.h"
#include "../simple.h"
#include "../errno.h"
#include <sys/errno.h>
#include <stddef.h>

long sys_iopolicysys(int cmd, void* arg)
{
	return 0;
}

