#include "getattrlistbulk.h"
#include "../base.h"
#include "../errno.h"
#include <sys/errno.h>

long sys_getattrlistbulk()
{
	return -ENOTSUP;
}

