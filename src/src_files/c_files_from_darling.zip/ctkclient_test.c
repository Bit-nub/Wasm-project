#include <ctkclient_test.h>

void TKTokenTestSetHook(void (^block)(CFDictionaryRef attributes, TKTokenTestBlocks *blocks)) {
}
