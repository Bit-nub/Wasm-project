const char* CRGetCrashLogMessage(void)
{
	return 0;
}

void CRSetCrashLogMessage(const char* msg)
{
}

void CRSetCrashLogMessage2(const char* path)
{
}
