/**
 * homework 7.7
 */

#include <stdio.h>

void f(void);

int x = 15213;
int y = 15212;


int main()
{
	f();
	printf("x = %d, y = %d \n", x ,y);
	return 0;
}