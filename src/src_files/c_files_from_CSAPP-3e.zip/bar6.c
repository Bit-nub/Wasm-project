/* bar6.c */
#include <stdio.h>

char main;

void p2()
{
	printf("0x%x\n", main);
}