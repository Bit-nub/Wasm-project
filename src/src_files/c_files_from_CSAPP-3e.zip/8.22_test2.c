/* homework 8.22 test 2 */

#include <stdio.h>
#include <stdlib.h>

int main()
{
	while (1) {};
}