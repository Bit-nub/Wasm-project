/* homework 8.22 test 1 */

#include <stdio.h>
#include <stdlib.h>

int main()
{
	exit(8);
}