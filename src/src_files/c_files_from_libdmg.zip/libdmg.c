/*
 * libdmg.c
 *
 *  Created on: Dec 12, 2014
 *      Author: posixninja
 */


