
typedef int size_t;
typedef int wchar_t;
