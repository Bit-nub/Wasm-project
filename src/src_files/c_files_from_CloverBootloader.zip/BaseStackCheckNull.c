/** @file
 This file is purely empty as a work around for BaseStackCheck to pass MSVC build.

 Copyright (c) 2018, Intel Corporation. All rights reserved.<BR>
 SPDX-License-Identifier: BSD-2-Clause-Patent

**/

extern int __BaseStackCheckNull;
