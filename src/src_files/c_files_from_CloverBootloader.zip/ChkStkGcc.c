/** @file
  Provides hack function for passng GCC build.

  Copyright (c) 2006 - 2018, Intel Corporation. All rights reserved.<BR>
  SPDX-License-Identifier: BSD-2-Clause-Patent

**/

#include "BaseLibInternals.h"

/**
  Hack function for passing GCC build.
**/
VOID
__chkstk()
{
}

