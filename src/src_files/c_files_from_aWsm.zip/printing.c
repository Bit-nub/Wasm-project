#include <stdio.h>

void print_str(char* str);

int main() {
    print_str("Hello World!\n");
    return 0;
}
