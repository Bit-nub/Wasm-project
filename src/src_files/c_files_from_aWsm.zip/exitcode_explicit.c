#include <stdlib.h>

int main() {
    exit(120);
}
