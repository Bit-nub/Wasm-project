#include <config.h>
#include <stdio.h>
#include "proto.h"
#include "getargs.h"
#include "hplay.h"

long samp_rate = 8000;

int
audio_init(int argc, char **argv)
{
 return (0);
}

void
audio_term(void)
{
}

void
audio_play(int n, short *data)
{
}
