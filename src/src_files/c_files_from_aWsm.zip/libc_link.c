#include <stdio.h>

int main() {
    printf("We are alive!");
    return 0;
}
