int main() {
    return sizeof(long double);
}
