int main()
{
    char ch1;
    char ch2;
    ch1 = getchar();
    ch2 = getchar();
    printf("%d  %d", ch1, ch2);
    return 0;
}