
int sqlite3PcacheInitialize(void){
  return 0;
}
void sqlite3PcacheShutdown(void){ }
