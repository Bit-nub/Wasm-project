#include "complex_impl.h"

//FIXME
long double complex ccoshl(long double complex z)
{
	return ccosh(z);
}
