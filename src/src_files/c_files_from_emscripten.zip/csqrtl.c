#include "complex_impl.h"

//FIXME
long double complex csqrtl(long double complex z)
{
	return csqrt(z);
}
