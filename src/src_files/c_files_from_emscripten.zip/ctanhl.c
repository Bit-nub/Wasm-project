#include "complex_impl.h"

//FIXME
long double complex ctanhl(long double complex z)
{
	return ctanh(z);
}
