#include "complex_impl.h"

float (cimagf)(float complex z)
{
	return cimagf(z);
}
