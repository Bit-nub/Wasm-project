#include <complex.h>

float (crealf)(float complex z)
{
	return crealf(z);
}
