#include "pthread_impl.h"

unsigned __default_stacksize = DEFAULT_STACK_SIZE;
unsigned __default_guardsize = DEFAULT_GUARD_SIZE;
