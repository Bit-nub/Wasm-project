#include "pthread_impl.h"

volatile int __abort_lock[1];
