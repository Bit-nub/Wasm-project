/* $begin fpgreater-ans-c */
int greater(double x, double y) 
{ 
    return x > y; 
} 
/* $end fpgreater-ans-c */
