/* Example of stack frame */
#include <stdio.h>

/* $begin frame-prob-c */
int proc(void)
{
    int x,y;
    scanf("%x %x", &y, &x);
    return x-y;
}
/* $end frame-prob-c */
