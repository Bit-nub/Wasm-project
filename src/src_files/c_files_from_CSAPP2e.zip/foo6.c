/* $begin foo6 */
/* foo6.c */ 
void p2(void);

int main()  
{  
    p2();  
    return 0;
}  
/* $end foo6 */
