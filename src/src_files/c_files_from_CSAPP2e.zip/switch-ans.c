/* $begin switch-ans-c */
int switch_prob(int x, int n) 
{ 
    int result = x; 

    switch(n) { 

	/* Fill in code here */ 
    } 

    return result; 
} 
/* $end switch-ans-c */



