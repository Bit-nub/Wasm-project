#include "csapp.h"

/* $begin hello-c */
int main()
{
    write(1, "hello, world\n", 13);
    exit(0);
}
/* $end hello-c */

