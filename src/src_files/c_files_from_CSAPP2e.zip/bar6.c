/* $begin bar6 */
/* bar6.c */ 
#include <stdio.h>

char main;  

void p2()  
{  
    printf("0x%x\n", main);  
}  
/* $end bar6 */
