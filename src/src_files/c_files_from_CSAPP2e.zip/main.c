#include <stdio.h>

int sum(int, int);

/* $begin summain-c */
int main()
{
    return sum(1, 3);
}
/* $end summain-c */
