#include <stdlib.h>
#include <stdio.h>

int main()
{
    size_t dsize = sizeof(size_t);
    printf("size_t requires %d bytes\n", dsize);
    return 0;
}
