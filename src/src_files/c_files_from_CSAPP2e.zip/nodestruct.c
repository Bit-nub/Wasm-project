/* $begin nodestruct-c */
struct NODE_S {
    struct NODE_S *left;
    struct NODE_S *right;
    double data;
};
/* $end nodestruct-c */

