/* $begin deref */
/* Dereference pointer or return 0 if null */
int deref(int *xp)
{
    return xp ? *xp : 0;
}
/* $end deref */


