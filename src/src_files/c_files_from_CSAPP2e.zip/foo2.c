/* $begin foo2 */
/* foo2.c */ 
int x = 15213; 
 
int main()  
{ 
    return 0;
} 
/* $end foo2 */
