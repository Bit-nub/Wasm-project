/* Starter functions for tmult_ok and umult_ok */

