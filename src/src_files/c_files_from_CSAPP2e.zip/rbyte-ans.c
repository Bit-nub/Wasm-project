/* $begin rbyte-proto */
unsigned replace_byte (unsigned x, int i, unsigned char b); 
/* $end rbyte-proto */

unsigned replace_byte (unsigned x, int i, unsigned char b) {
  /* Solution omitted */
  return x;
} 
/* $end rbyte-ans */

/* $begin pbyte-proto */
unsigned put_byte (unsigned x, unsigned char b, int i); 
/* $end pbyte-proto */
