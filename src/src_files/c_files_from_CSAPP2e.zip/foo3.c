/* $begin foo3 */
/* foo3.c */ 
#include <stdio.h>
void f(void);

int x = 15213; 

int main()  
{ 
    f(); 
    printf("x = %d\n", x); 
    return 0;
} 
/* $end foo3 */
 
