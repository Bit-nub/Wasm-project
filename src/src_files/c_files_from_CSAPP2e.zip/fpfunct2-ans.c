/* $begin fpfunct2-ans-c */
double funct2(int p, double q, float r, float s) 
{ 
    return p/(q+r) - (s+1); 
} 
/* $end fpfunct2-ans-c */

