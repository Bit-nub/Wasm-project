#include "csapp.h"

/* $begin fork1 */
/* $begin wasidefork1 */
int main() 
{
    Fork();
    printf("hello\n");
    exit(0);
}
/* $end fork1 */
/* $end wasidefork1 */
