/* $begin aligns1-c */
struct S1 { 
    int  i; 
    char c; 
    int  j; 
}; 
/* $end aligns1-c */

/* $begin aligns2-c */
struct S2 { 
    int  i; 
    int  j; 
    char c; 
}; 
/* $end aligns2-c */


