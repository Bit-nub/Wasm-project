extern int recover_main(int argc, char **argv);

int main(int argc, char **argv)
{
    return recover_main(argc, argv);
}
