/* Basic file operations, now *with* sysroot.
#sim: --sysroot=@exedir@
*/
#define PREFIX "/"
#include "check_openpf3.c"
