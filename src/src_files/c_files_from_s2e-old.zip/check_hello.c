#include <stdio.h>
#include <stdlib.h>
int main ()
{
  printf ("pass\n");
  exit (0);
}
