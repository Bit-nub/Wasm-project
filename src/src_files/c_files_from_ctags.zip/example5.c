/* https://github.com/antlr/grammars-v4/blob/master/tinyc/examples/example5.c */
{ i=7; if (i<5) x=1; if (i<10) y=2; }
