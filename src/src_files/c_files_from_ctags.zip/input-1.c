#ifndef __ASSEMBLER__

inline void do_nothing_1(void) {}

#endif
