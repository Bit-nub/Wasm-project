struct {
	char *name;
} x;
