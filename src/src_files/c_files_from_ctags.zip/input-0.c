#ifdef __ASSEMBLER__

	.macro	DO_NOTHING_0
	 nop
	.endm

#endif
