/* https://github.com/antlr/grammars-v4/blob/master/tinyc/examples/example3.c */
{ i=1; do i=i+10; while (i<50); }
