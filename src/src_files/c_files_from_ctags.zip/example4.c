/* https://github.com/antlr/grammars-v4/blob/master/tinyc/examples/example4.c */
{ i=1; while ((i=i+10)<50) ; }
