/* ./ctags --fields='*' -o output.tags sample.c */
int abc;
int efg;
