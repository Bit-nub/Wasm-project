#define CONFIG_APCI_1710 1

#define ADDIDATA_DRIVER_NAME	"addi_apci_1710"

#include "addi-data/addi_common.c"
