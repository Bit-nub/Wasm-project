#define CONFIG_APCI_3501 1

#define ADDIDATA_DRIVER_NAME	"addi_apci_3501"

#include "addi-data/addi_common.c"

MODULE_AUTHOR("Comedi http://www.comedi.org");
MODULE_DESCRIPTION("Comedi low-level driver");
MODULE_LICENSE("GPL");
