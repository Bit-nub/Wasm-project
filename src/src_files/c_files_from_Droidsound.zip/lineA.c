/* lineA.c - EMU68 generated code by
 * gen68 2013-05-25 00:26:49
 * Copyright (C) 1998-2013 Benjamin Gerard
 *
 * $Id: lineA.c 228 2013-05-24 23:28:08Z benjihan $
 */

/* Line A: (Unassigned, Reserved) */

DECL_LINE68(lineA00)
{
  LINEA;
}

