/* lineF.c - EMU68 generated code by
 * gen68 2013-05-25 00:26:49
 * Copyright (C) 1998-2013 Benjamin Gerard
 *
 * $Id: lineF.c 228 2013-05-24 23:28:08Z benjihan $
 */

/* Line F: Coprocessor Interface/MC68040 and CPU32 Extensions */

DECL_LINE68(lineF00)
{
  LINEF;
}

