#include "mamedef.h"

#define OPLTYPE_IS_OPL3
#include "adlibemu.h"
#include "opl.c"
