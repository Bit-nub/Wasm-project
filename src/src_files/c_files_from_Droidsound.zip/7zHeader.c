/*  7zHeader.c -- 7z Headers
2008-10-04 : Igor Pavlov : Public domain */

#include "7zHeader.h"

Byte k7zSignature[k7zSignatureSize] = {'7', 'z', 0xBC, 0xAF, 0x27, 0x1C};
