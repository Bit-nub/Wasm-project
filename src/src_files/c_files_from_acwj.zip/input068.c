typedef int FOO;
typedef char FOO;
