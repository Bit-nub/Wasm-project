fred says hello
