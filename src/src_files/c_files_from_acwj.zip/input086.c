int main() {
  int fred() { return(5); }
  int x;
  x=2;
  return(x);
}
