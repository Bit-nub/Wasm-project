int main() { int a; a= --5; }
