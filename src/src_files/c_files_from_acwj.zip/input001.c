int printf(char *fmt);

void main()
{ printf("%d\n", 12 * 3);
  printf("%d\n", 18 - 2 * 4);
  printf("%d\n", 1 + 2 + 9 - 5/2 + 3*5);
}
