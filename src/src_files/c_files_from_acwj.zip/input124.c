#include <stdio.h>

int ary[5];

int main() {
  ary++;
  return(0);
}
