Integer literal value too big for char type on line 1 of input092.c
