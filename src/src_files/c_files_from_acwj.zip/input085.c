int main(struct foo { int x; }; , int a) {
  return(0);
}
