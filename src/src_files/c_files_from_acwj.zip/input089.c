#include <stdio.h>

int x= 23;
char y= 'H';
char *z= "Hello world";

int main() {
  printf("%d %c %s\n", x, y, z);
  return(0);
}
