extern int fred;
int fred;

int mary;
extern int mary;

int main() { return(0); }
