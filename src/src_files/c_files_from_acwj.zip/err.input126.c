Unknown variable or function:ptr on line 7 of input126.c
