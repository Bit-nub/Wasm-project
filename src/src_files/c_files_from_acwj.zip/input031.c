int printf(char *fmt);

int main() {
  int x;
  x= 2 + + 3 - * / ;
}
