Unknown variable:z on line 1
