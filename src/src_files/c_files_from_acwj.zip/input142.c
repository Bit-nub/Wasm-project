static int fred[];
int jim;
