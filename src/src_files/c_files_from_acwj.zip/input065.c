enum fred { x, y, z };
enum fred { a, b };
