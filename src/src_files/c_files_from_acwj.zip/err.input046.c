* operator must be followed by an identifier or * on line 3 of input046.c
