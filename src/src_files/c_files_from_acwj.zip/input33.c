int main() {
  char *z; return(z);
}
