int printf(char *fmt);

int fred(int a, int b) {
  int a;
  return(a);
}
