char *s= 54;
