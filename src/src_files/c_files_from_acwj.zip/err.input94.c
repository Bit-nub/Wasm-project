Type mismatch: integer literal vs. variable on line 1 of input94.c
