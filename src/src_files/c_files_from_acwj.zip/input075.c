int main() {
  int x;
  switch(x) {
    if (x<5);
  }
}
