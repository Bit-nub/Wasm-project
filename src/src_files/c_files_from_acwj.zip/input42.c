int main() { fred(5); }
