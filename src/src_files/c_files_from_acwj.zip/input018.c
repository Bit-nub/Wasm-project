int printf(char *fmt);

int main()
{
  int a;
  int b;
  a= b= 34;
  printf("%d\n", a);
  printf("%d\n", b);
  return(0);
}
