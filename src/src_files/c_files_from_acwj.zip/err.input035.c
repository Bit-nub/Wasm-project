Duplicate local variable declaration:a on line 4 of input035.c
