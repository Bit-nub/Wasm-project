++ operator must be followed by an identifier on line 3 of input047.c
