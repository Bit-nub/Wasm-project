++ operator must be followed by an identifier on line 1
