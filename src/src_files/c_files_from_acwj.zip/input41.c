void fred() { return(5); }
