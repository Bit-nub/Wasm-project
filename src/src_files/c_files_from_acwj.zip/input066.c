enum fred { x, y, z };
enum mary { a, b, z };
