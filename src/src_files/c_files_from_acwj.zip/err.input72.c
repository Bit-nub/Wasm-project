no loop or switch to break out from on line 1 of input72.c
