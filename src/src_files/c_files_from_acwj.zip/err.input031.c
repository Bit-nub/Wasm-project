Expecting a primary expression, got token:+ on line 5 of input031.c
