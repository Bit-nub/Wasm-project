#include <stdio.h>

int x= 6;

int main() {
  printf("%d\n", x++ ++);
  return(0);
}

