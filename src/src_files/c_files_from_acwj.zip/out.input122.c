x 0, y 0, x || y 0, x && y 0
x 0, y 1, x || y 1, x && y 0
x 1, y 0, x || y 1, x && y 0
x 1, y 1, x || y 1, x && y 1
