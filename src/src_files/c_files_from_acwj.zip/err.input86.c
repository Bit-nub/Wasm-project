Function definition not at global level on line 3 of input86.c
