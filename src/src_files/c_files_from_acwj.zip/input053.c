int printf(char *fmt);

int main()
{
  printf("Hello world, %d\n", 23);
  return(0);
}
