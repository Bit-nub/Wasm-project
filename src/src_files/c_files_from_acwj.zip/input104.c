int main() {
  int y= (void) x;
}
