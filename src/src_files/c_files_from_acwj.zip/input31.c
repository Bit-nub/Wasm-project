int main() {
  int x;
  x= 2 + + 3 - * / ;
}
