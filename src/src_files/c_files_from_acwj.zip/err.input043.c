Undeclared array:b on line 3 of input043.c
