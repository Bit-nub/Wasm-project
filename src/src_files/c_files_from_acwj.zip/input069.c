typedef int FOO;
FLOO y;
