int a;
int b;
int c;

int main()
{
  char z;
  int y;
  int x;
  x= 10; y= 20; z= 30;
  printint(x); printint(y); printint(z);
  a= 5; b= 15; c= 25;
  printint(a); printint(b); printint(c);
  return(0);
}
