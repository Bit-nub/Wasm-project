Duplicate case value on line 6 of input079.c
