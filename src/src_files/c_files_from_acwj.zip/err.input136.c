Must return a value from a non-void function on line 4 of input136.c
