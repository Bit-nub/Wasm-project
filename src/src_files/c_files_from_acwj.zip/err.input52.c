Unrecognised character:$ on line 3
