fish
cow
NULL
