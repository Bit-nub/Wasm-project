int printf(char *fmt);

int main() { fred(5); }
