Undeclared variable:x on line 3 of input061.c
