int main() {
  pizza cow llama sausage;
}
