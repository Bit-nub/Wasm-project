int printf(char *fmt);

int main() {
  char *z; return(z);
}
