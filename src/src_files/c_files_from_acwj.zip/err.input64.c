undeclared enum type::fred on line 1
