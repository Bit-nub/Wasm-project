i is 1
i is 2
i is 3
leftover owl
