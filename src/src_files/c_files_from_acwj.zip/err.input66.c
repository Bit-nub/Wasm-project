enum value redeclared::z on line 2
