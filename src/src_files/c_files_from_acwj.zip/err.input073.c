no loop to continue to on line 1 of input073.c
