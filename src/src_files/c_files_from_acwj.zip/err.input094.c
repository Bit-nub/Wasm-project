Type mismatch: integer literal vs. variable on line 1 of input094.c
