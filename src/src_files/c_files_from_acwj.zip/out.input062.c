65
66
66
The next two depend on the endian of the platform
66
66
67
67
