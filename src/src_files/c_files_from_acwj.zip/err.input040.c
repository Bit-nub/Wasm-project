No return for function with non-void type on line 4 of input040.c
