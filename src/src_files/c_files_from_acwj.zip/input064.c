enum fred var3;
