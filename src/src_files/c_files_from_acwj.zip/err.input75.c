Unexpected token in switch:27 on line 4 of input75.c
