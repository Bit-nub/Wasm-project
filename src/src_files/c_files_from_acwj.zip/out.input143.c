One of the three is NULL
One of the three is NULL
One of the three is NULL
All  three  are non-NULL
