int printf(char *fmt);

int main() {
  pizza cow llama sausage;
}
