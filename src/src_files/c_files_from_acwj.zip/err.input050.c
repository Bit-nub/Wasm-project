Incompatible types in binary expression on line 6 of input050.c
