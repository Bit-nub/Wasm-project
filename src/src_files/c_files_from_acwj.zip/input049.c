int printf(char *fmt);

int main() {
 int x;
 char y;
 y= x;
}
