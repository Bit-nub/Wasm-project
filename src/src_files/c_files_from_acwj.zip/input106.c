#include <stdio.h>
char *y= (char *)0;

int main() {
  printf("0x%lx\n", (long)y);
  return(0);
}
