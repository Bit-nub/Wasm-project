int main() {
  int x;
  x= y.foo;
}
