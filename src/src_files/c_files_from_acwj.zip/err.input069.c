unknown type:FLOO on line 2 of input069.c
