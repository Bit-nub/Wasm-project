int printf(char *fmt);

int main() {
  char a; a= 'fred';
}
