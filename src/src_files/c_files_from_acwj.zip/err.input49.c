Incompatible expression in assignment on line 4
