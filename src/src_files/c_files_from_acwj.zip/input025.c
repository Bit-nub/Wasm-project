int printf(char *fmt);

int a;
int b;
int c;

int main()
{
  char z;
  int y;
  int x;
  x= 10; y= 20; z= 30;
  printf("%d\n", x); printf("%d\n", y); printf("%d\n", z);
  a= 5; b= 15; c= 25;
  printf("%d\n", a); printf("%d\n", b); printf("%d\n", c);
  return(0);
}
