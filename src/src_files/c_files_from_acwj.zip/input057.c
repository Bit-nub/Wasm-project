struct fred { int x;  } ;
struct fred { char y; } ;
