int printf(char *fmt);

int fred(int a, char b, int c);
int fred(int a, int b, char c, int g);
