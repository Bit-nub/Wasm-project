int main() {
  char *str= (void *)0;
  return(0);
}
