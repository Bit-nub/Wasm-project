int printf(char *fmt);

void main()
{
  int x;
  x= 1;     printf("%d\n", x);
  x= x + 1; printf("%d\n", x);
  x= x + 1; printf("%d\n", x);
  x= x + 1; printf("%d\n", x);
  x= x + 1; printf("%d\n", x);
}
