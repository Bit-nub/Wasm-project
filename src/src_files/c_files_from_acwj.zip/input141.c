static int fred[5];
int jim;

int foo(int mary[6]) { return(5); }
