int fred(int a, char b +, int z);
