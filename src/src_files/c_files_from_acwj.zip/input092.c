char x= 3000;
