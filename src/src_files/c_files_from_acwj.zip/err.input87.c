Bad type in member list on line 4 of input87.c
