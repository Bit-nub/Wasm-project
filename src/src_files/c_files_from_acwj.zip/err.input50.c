Incompatible types in binary expression on line 4
