int main() {
  int x;
  switch(x) { }
}
