No cases in switch on line 3 of input076.c
