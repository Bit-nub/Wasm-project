int printf(char *fmt);

void main()
{
  int i; int j;
  i=6; j=12;
  if (i < j) {
    printf("%d\n", i);
  } else {
    printf("%d\n", j);
  }
}
