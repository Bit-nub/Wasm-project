Array size is illegal:0 on line 1 of input96.c
