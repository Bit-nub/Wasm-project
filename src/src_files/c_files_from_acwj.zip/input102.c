int main() {
  struct foo { int p; };
  int y= (struct foo) x;
}
