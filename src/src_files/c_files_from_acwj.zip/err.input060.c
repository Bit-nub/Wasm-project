Undeclared variable:x on line 3 of input060.c
