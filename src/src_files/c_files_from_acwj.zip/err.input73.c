no loop to continue to on line 1 of input73.c
