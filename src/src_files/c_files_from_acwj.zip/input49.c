int main() {
 int x;
 char y;
 y= x;
}
