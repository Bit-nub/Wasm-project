Type doesn't match prototype for parameter:2 on line 4 of input038.c
