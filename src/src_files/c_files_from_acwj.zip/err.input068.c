redefinition of typedef:FOO on line 2 of input068.c
