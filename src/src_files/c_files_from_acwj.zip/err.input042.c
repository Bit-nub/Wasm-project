Undeclared function:fred on line 3 of input042.c
