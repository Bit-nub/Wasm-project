int printf(char *fmt);

int main() {
 int a[12];
 return(0);
}
