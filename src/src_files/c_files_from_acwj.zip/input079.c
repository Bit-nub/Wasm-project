int main() {
  int x;
  switch(x) {
    case 1: { x= 2; }
    case 2: { x= 2; }
    case 1: { x= 2; }
    default: { x= 2; }
  }
}
