Expected '\'' at end of char literal on line 2
