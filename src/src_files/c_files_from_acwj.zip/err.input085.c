Bad type in parameter list on line 1 of input085.c
