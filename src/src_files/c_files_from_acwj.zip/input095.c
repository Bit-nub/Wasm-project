int fred(int x=2) { return(x); }
