No statements in function with non-void type on line 4 of input039.c
