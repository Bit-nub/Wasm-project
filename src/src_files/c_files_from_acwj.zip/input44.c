int main() { int a; a= z; }
