#include <stdio.h>
int main() {
  int x= 17 - 1;
  printf("%d\n", x);
  return(0);
}
