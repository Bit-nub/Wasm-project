int main(void) {
  static int x;
}
