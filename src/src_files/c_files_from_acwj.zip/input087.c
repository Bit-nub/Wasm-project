struct foo {
  int x;
  int y;
  struct blah { int g; };
};
