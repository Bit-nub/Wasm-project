Undeclared array:b on line 1
