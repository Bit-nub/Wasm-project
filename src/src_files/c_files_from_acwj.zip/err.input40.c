No return for function with non-void type on line 2
