Hello world
Argument 0 is ./out
