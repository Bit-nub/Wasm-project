Undeclared variable:y on line 3 of input059.c
