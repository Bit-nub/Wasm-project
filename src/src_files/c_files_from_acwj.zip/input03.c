void main()
{
  int x;
  x= 1;     printint(x);
  x= x + 1; printint(x);
  x= x + 1; printint(x);
  x= x + 1; printint(x);
  x= x + 1; printint(x);
}
