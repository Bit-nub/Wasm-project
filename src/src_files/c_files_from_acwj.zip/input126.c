#include <stdio.h>

int ary[5];

int main() {
  ary[3]= 2008;
  ptr= &ary;
  return(0);
}
