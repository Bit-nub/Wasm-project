Expected '\'' at end of char literal on line 4 of input051.c
