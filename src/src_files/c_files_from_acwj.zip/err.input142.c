Array must have non-zero elements:fred on line 1 of input142.c
