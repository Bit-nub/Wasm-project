For now, declaration of local arrays is not implemented on line 2
