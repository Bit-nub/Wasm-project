Cannot ++ and/or -- more than once on line 6 of input129.c
