int main()
{
  int a;
  int b;
  a= b= 34;
  printint(a);
  printint(b);
  return(0);
}
