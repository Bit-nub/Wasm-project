int fred[0];
