Incompatible expression in assignment on line 6 of input049.c
