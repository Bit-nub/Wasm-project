#include <stdio.h>

int a = 23, b = 100;
char y = 'H', *z = "Hello world";

int main() {
  printf("%d %d %c %s\n", a, b, y, z);
  return (0);
}
