Expecting an integer literal value on line 1 of input93.c
