For now, declaration of non-global arrays is not implemented on line 2 of input97.c
