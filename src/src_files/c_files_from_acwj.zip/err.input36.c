Type doesn't match prototype for parameter:3 on line 2
