int printf(char *fmt);

void fred() { return(5); }
