Can't return from a void function on line 3 of input041.c
