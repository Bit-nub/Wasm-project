int main() {
  int x;
  switch(x) {
    case 1: { x= 2; }
    default: { x= 3; }
    default: { x= 2; }
  }
}
