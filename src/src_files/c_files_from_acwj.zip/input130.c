#include <stdio.h>

char *x= "foo";

int main() {
  printf("Hello " "world" "\n");
  return(0);
}
