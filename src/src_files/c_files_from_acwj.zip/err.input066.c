enum value redeclared::z on line 2 of input066.c
