void main()
{ int i;
  i=1;
  while (i <= 10) {
    printint(i);
    i= i + 1;
  }
}
