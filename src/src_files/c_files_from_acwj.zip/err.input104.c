Cannot cast to a struct, union or void type on line 2 of input104.c
