Unexpected token in switch:if on line 4 of input075.c
