For now, declaration of non-global arrays is not implemented on line 4 of input034.c
