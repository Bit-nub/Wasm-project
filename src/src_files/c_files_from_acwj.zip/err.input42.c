Undeclared function:fred on line 1
