x is 36
