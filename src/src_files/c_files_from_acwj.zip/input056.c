struct foo { int x; };
struct mary var1;
