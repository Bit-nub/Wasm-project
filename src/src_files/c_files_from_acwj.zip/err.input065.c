enum type redeclared::fred on line 2 of input065.c
