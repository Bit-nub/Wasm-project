int main() {
 int a[12];
 return(0);
}
