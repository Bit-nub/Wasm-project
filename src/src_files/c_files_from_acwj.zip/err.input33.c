Incompatible type to return on line 2
