Undeclared variable:x on line 3
