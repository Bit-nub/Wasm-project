Undeclared variable:y on line 3
