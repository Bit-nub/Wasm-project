int main() {
 char *a;
 char *b;
 a= a + b;
}
