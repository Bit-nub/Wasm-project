Bad type in member list on line 4 of input087.c
