Compiler doesn't support static or extern local declarations on line 2 of input118.c
