char x= fred;
