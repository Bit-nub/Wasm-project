void main()
{
  int i;
  for (i= 1; i <= 10; i= i + 1) {
    printint(i);
  }
}
