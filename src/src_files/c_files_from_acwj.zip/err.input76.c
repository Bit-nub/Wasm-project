No cases in switch on line 3 of input76.c
