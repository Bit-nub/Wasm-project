Unknown variable:cow on line 2
