case or default after existing default on line 6 of input078.c
