int main() {
  int x;
  x= x.foo;
}
