int main() {
 int x[45];
 return(0);
}
