Incompatible type to return on line 4 of input033.c
