Declaration of array parameters is not implemented on line 4 of input141.c
