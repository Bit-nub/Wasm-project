Can't return from a void function on line 1
