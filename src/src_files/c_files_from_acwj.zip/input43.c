int main() { int a; a= b[4]; }
