#include <stdio.h>
int main() {
  int x= 0x4a;
  printf("%c\n", x);
  return(0);
}
