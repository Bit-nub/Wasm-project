undeclared enum type::fred on line 1 of input064.c
