unknown struct/union type:var1 on line 2
