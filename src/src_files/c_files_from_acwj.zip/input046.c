int printf(char *fmt);

int main() { int a; a= *5; }
