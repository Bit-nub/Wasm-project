unknown struct/union type:var1 on line 2 of input056.c
