Cannot ++ on rvalue on line 6 of input124.c
