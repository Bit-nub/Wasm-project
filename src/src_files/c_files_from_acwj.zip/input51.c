int main() {
  char a; a= 'fred';
}
