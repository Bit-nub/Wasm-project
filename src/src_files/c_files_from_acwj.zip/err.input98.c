Too many values in initialisation list on line 1 of input98.c
