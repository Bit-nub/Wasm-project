Unrecognised character:$ on line 5 of input052.c
