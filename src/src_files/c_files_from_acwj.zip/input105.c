int main() {
  int x;
  char *y;
  y= (char) x;
}
