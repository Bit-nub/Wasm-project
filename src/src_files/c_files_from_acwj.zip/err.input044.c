Unknown variable:z on line 3 of input044.c
