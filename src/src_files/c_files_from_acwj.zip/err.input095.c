Variable can not be initialised:x on line 1 of input095.c
