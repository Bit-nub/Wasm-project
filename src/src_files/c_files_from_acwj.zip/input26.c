int main(int a, char b, long c, int d, int e, int f, int g, int h) {
  int i; int j; int k;

  a= 13; printint(a);
  b= 23; printint(b);
  c= 34; printint(c);
  d= 44; printint(d);
  e= 54; printint(e);
  f= 64; printint(f);
  g= 74; printint(g);
  h= 84; printint(h);
  i= 94; printint(i);
  j= 95; printint(j);
  k= 96; printint(k);
  return(0);
}
