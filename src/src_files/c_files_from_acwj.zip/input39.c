int main() { int a; }
