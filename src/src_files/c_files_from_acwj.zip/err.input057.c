previously defined struct/union:fred on line 2 of input057.c
