* operator must be followed by an identifier or * on line 1
