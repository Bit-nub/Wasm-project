Duplicate local variable declaration:a on line 2
