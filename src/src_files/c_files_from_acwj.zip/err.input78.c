case or default after existing default on line 6 of input78.c
