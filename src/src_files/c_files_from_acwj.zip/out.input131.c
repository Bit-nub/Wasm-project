Doing nothing... nothing done
x is now 100
