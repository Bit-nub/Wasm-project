enum type redeclared::fred on line 2
