Function definition not at global level on line 3 of input086.c
