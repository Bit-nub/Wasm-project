0 0 | 0
0 1 | 0
1 0 | 0
1 1 | 1
0 0 | 0
0 1 | 1
1 0 | 1
1 1 | 1
aptr is NULL or doesn't point at 1
aptr points at 1
