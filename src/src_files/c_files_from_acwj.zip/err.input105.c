Incompatible expression in assignment on line 4 of input105.c
