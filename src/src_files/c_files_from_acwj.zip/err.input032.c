Unknown variable:cow on line 4 of input032.c
