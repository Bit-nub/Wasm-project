redefinition of typedef:FOO on line 2
