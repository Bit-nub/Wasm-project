int printf(char *fmt);

int main(int a, char b, long c, int d, int e, int f, int g, int h) {
  int i; int j; int k;

  a= 13; printf("%d\n", a);
  b= 23; printf("%d\n", b);
  c= 34; printf("%d\n", c);
  d= 44; printf("%d\n", d);
  e= 54; printf("%d\n", e);
  f= 64; printf("%d\n", f);
  g= 74; printf("%d\n", g);
  h= 84; printf("%d\n", h);
  i= 94; printf("%d\n", i);
  j= 95; printf("%d\n", j);
  k= 96; printf("%d\n", k);
  return(0);
}
