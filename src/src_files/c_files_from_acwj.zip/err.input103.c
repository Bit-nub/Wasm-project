Cannot cast to a struct, union or void type on line 3 of input103.c
