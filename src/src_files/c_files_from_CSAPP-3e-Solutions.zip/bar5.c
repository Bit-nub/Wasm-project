/*
 * bar5.c
 */
double x;

void f() {
  /*x = -0.0;*/
}
