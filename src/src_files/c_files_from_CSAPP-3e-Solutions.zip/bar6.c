/*
 * bar6.c
 */
#include <stdio.h>

unsigned int main;

void p2() {
  printf("0x%x\n", main);
}
