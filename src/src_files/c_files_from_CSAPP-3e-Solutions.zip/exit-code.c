/*
 * exit-code.c
 */
#include "csapp.h"

int main(int argc, char* argv[]) {
  exit(10);
}


