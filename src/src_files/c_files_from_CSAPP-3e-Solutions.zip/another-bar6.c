/*
 * another-bar6.c
 */
#include <stdio.h>

int main(int argc, char* argv[]);

void p2() {
  printf("0x%x\n", * (unsigned int *)main);
}
