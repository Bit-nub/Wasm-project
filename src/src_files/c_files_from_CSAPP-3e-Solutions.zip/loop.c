/*
 * 8.loop.c
 */
#include <stdio.h>
#include "../csapp.h"

int main(int argc, char* argv[]) {
  while (1) {
    Sleep(2);
  }
}


