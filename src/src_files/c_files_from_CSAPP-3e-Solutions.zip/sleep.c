/*
 * 8.sleep.c
 */
#include <stdio.h>
#include "../csapp.h"

int main(int argc, char* argv[]) {
  Sleep(5);
  return 0;
}


