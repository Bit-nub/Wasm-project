/*
 * foo6.c
 */
void p2(void);

void offset(void) {
  return;
}

int main(int argc, char* argv[]) {
  p2();
  return 0;
}


