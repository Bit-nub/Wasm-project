/*
 * wait-sig.c
 */
#include "csapp.h"

int main(int argc, char* argv[]) {
  while (1);
}


