// RpcInterface_c.c expects _ARM_ to be set when building for ARM.
#ifdef _M_ARM
#define _ARM_ 1
#endif

#include "RpcInterface_c.c"
