/*--
Copyright (C) Microsoft Corporation. All rights reserved.
--*/

#include "initguid.h"
#include "ntddk.h"
#include "ntddstor.h"
#include "mountmgr.h"
#include "ioevent.h"
#include "devpkey.h"
#include "wdmguid.h"

// no code, just GUIDs being defined



