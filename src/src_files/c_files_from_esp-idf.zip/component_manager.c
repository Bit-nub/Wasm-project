#include <stdio.h>
#include "cmp.h"

void app_main(void)
{
    cmp_hello();
}
