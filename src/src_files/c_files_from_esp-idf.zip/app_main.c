#include "test_utils.h"

void app_main(void)
{
    test_main();
}
