
#include "lib_acl.h"
#include "unit_test.h"
#include "unit_test_tab.h"

void test_unit_register()
{
	aut_register(__test_fn_tab);
}

