/**
 * Copyright (c) 2011 - 2017, Nordic Semiconductor ASA
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 * 
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 * 
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 * 
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#include "nrf_delay.h"


#if defined ( __CC_ARM   )
void nrf_delay_us(uint32_t number_of_us)
{
    if(!number_of_us)
        return;
__asm
    {
loop:
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    CMP SystemCoreClock, CLOCK_FREQ_16MHz
    BEQ cond
    NOP
#if defined(NRF52) || defined(NRF52840_XXAA) || defined(NRF52832)
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
    NOP
#endif
cond:
    SUBS number_of_us, #1
    BNE loop
    }
}

#elif defined ( _WIN32 ) || defined ( __unix ) || defined( __APPLE__ )


#ifndef CUSTOM_NRF_DELAY_US
void nrf_delay_us(uint32_t number_of_us)
{}
#endif

#elif defined ( __GNUC__ ) || ( __ICCARM__ )

void nrf_delay_us(uint32_t number_of_us)
{
    const uint32_t clock16MHz = CLOCK_FREQ_16MHz;
    if (number_of_us)
    {
__ASM volatile (
#if ( defined(__GNUC__) && (__CORTEX_M == (0x00U) ) )
    ".syntax unified\n"
#endif
"1:\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " CMP %[SystemCoreClock], %[clock16MHz]\n"
       " BEQ.N 2f\n"
       " NOP\n"
#if defined(NRF52) || defined(NRF52840_XXAA) || defined(NRF52832)
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
       " NOP\n"
#endif
"2:\n"
       " SUBS %[number_of_us], #1\n"
       " BNE.N 1b\n"
#if ( defined(__GNUC__) && (__CORTEX_M == (0x00U) ) )
    ".syntax divided\n"
#endif
#if ( __CORTEX_M == (0x00U) )
    // The SUBS instruction in Cortex-M0 is available only in 16-bit encoding,
    // hence it requires a "lo" register (r0-r7) as an operand.
    : [number_of_us]    "=l"             (number_of_us)
#else
    : [number_of_us]    "=r"             (number_of_us)
#endif
    : [SystemCoreClock] "r"              (SystemCoreClock),
      [clock16MHz]      "r"              (clock16MHz),
                        "[number_of_us]" (number_of_us)
    );
    }
}
#endif

void nrf_delay_ms(uint32_t number_of_ms)
{
    nrf_delay_us(1000*number_of_ms);
}

