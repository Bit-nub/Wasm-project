#include <stdio.h>

int main() {
    printf("hahaha\n");
    return 0;
}
