// 0x05002528
static const struct Animation bookend_seg5_anim_05002528 = {
    0,
    0,
    0,
    0,
    0x01,
    ANIMINDEX_NUMPARTS(bookend_seg5_animindex_0500248C),
    bookend_seg5_animvalue_0500240C,
    bookend_seg5_animindex_0500248C,
    0,
};
