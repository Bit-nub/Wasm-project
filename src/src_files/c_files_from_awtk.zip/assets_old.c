#include "awtk.h"
#ifdef AWTK_WEB
#include "assets.inc"
#else /*AWTK_WEB*/
#include "../res/assets_old.inc"
#endif /*AWTK_WEB*/
