﻿#include "base/main_loop.h"

/*for test program.*/
main_loop_t* main_loop_init(int w, int h) {
  (void)w;
  (void)h;
  return NULL;
}
