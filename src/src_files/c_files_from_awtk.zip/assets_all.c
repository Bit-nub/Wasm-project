#include "awtk.h"
#ifdef AWTK_WEB
#include "assets.inc"
#else /*AWTK_WEB*/
#include "../res/assets_all.inc"
#endif /*AWTK_WEB*/
