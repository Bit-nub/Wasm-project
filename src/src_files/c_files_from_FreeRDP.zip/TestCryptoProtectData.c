

#include <winpr/crt.h>
#include <winpr/tchar.h>
#include <winpr/crypto.h>

int TestCryptoProtectData(int argc, char* argv[])
{
	return 0;
}
