
#include <winpr/crt.h>
#include <winpr/memory.h>

int TestMemoryCreateFileMapping(int argc, char* argv[])
{
	return 0;
}
