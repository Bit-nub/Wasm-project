
#include <stdio.h>
#include <winpr/crt.h>
#include <winpr/file.h>
#include <winpr/windows.h>

int TestFileFindFirstFileEx(int argc, char* argv[])
{
	return 0;
}
