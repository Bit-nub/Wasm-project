#include	<stdio.h>

main()
{
	printf("hello, world\n");
}
