/* This file is in the public domain. */
/* $FreeBSD$ */
#include "blake2b.c"
