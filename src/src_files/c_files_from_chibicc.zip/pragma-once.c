#include "test.h"

#pragma once

#include "test/pragma-once.c"

int main() {
  printf("OK\n");
  return 0;
}
