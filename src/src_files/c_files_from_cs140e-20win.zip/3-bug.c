/* bug 1 */
#include "rpi.h"
void notmain(void) {
    printk("about to start\n");
}
