// warm-up: what will the compiler do?
void foo(void) {
    int i = 0;
    return;
}
