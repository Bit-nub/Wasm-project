#include <stdio.h>

int main() { 
	int p[10];
	int i = 100000;

	if((i < 10) & (p[i] == 10))
		printf("true\n");
	else
		printf("false\n");

	return 0;
}
