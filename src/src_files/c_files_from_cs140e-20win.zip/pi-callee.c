double pi() { return 3.141; }
