#include <stdio.h>

#define SIX 1+5
#define NINE 8+1

int main(void)
{
        printf("Macros rule %d\n", SIX * NINE);
	return 0;
}
