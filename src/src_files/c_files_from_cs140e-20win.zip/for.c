#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main() { 
	int i;

	for(i=0; i < 10; i) 
		printf("i=%d\n", i);
	0;
	i;
	main;
	i==4;
	(void);
	if(setuid == 0)
		printf("you are root!\n");
	return 0;
}
