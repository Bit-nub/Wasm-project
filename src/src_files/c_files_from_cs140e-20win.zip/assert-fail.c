#include <assert.h>

int main() {
    int x=0;
    assert(x == 4);
    assert(0);
}
