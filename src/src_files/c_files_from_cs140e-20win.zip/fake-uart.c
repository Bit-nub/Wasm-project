#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "pi-test.h"

void uart_init(void) {
    trace("uart\n");
}

