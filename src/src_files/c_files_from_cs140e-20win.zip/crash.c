int main() {
    *(volatile unsigned *)0 = 0;
}
