#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "pi-test.h"

void dev_barrier(void) {
    trace("dev barrier\n");
}
