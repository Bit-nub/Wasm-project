int main(void) {
	foo();
	printf("pi=%f\n", pi());
}

int foo() { return 3; }
