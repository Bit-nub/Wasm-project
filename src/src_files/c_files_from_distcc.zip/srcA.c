#define INCL "inclA.h"
#include "helper.c"
#include <stdio.h>

int main() {
  printf(MSG);
  printf("\n");
  return 0;
}
