#define _GNU_SOURCE         /* See feature_test_macros(7) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>

#include "wrappedlibs.h"

#include "debug.h"
#include "wrapper.h"
#include "bridge.h"
#include "librarian/library_private.h"
#include "x86emu.h"
#include "emu/x86emu_private.h"
#include "callback.h"
#include "box86context.h"
#include "librarian.h"
#include "myalign.h"

const char* openalName = "libopenal.so.1";
#define LIBNAME openal
static char* libname = NULL;

#define ADDED_FUNCTIONS()           \

#include "generated/wrappedopenaltypes.h"

#include "wrappercallback.h"

#define SUPER() \
GO(0)   \
GO(1)   \
GO(2)   \
GO(3)   \
GO(4)

// Request ...
#define GO(A)   \
static uintptr_t my_Request_fct_##A = 0;                    \
static void my_Request_##A(int32_t a, int32_t b)            \
{                                                           \
    RunFunction(my_context, my_Request_fct_##A, 2, a, b);   \
}
SUPER()
#undef GO
static void* find_Request_Fct(void* fct)
{
    if(!fct) return fct;
    if(GetNativeFnc((uintptr_t)fct))  return GetNativeFnc((uintptr_t)fct);
    #define GO(A) if(my_Request_fct_##A == (uintptr_t)fct) return my_Request_##A;
    SUPER()
    #undef GO
    #define GO(A) if(my_Request_fct_##A == 0) {my_Request_fct_##A = (uintptr_t)fct; return my_Request_##A; }
    SUPER()
    #undef GO
    printf_log(LOG_NONE, "Warning, no more slot for zlib Request callback\n");
    return NULL;
}

#undef SUPER

void fillALProcWrapper();

EXPORT void* my_alGetProcAddress(x86emu_t* emu, void* name) 
{
    khint_t k;
    const char* rname = (const char*)name;
    printf_log(LOG_DEBUG, "Calling alGetProcAddress(%s)\n", rname);
    if(!emu->context->alwrappers)   // could be moved in "my" structure...
        fillALProcWrapper();
    // get proc adress using actual alGetProcAddress
    k = kh_get(symbolmap, emu->context->almymap, rname);
    int is_my = (k==kh_end(emu->context->almymap))?0:1;
    void* symbol;
    if(is_my) {
        // try again, by using custom "my_" now...
        char tmp[200];
        strcpy(tmp, "my_");
        strcat(tmp, rname);
        symbol = dlsym(emu->context->box86lib, tmp);
    } else 
        symbol = my->alGetProcAddress(name);
    if(!symbol)
        return NULL;    // easy
    // check if alread bridged
    uintptr_t ret = CheckBridged(emu->context->system, symbol);
    if(ret)
        return (void*)ret; // already bridged
    // get wrapper    
    k = kh_get(symbolmap, emu->context->alwrappers, rname);
    if(k==kh_end(emu->context->alwrappers)) {
        printf_log(LOG_INFO, "Warning, no wrapper for %s\n", rname);
        return NULL;
    }
    const char* constname = kh_key(emu->context->alwrappers, k);
    AddOffsetSymbol(emu->context->maplib, symbol, rname);
    return (void*)AddBridge(emu->context->system, kh_value(emu->context->alwrappers, k), symbol, 0, constname);
}

EXPORT void* my_alcGetProcAddress(x86emu_t* emu, void* device, void* name)
{
    khint_t k;
    const char* rname = (const char*)name;
    printf_log(LOG_DEBUG, "Calling alcGetProcAddress(%p, %s)\n", device, rname);
    if(!emu->context->alwrappers)   // could be moved in "my" structure...
        fillALProcWrapper();
    // get proc adress using actual alGetProcAddress
    k = kh_get(symbolmap, emu->context->almymap, rname);
    int is_my = (k==kh_end(emu->context->almymap))?0:1;
    void* symbol;
    if(is_my) {
        // try again, by using custom "my_" now...
        char tmp[200];
        strcpy(tmp, "my_");
        strcat(tmp, rname);
        symbol = dlsym(emu->context->box86lib, tmp);
    } else 
        symbol = my->alcGetProcAddress(device, name);
    if(!symbol)
        return NULL;    // easy
    uintptr_t ret = CheckBridged(emu->context->system, symbol);
    if(ret)
        return (void*)ret; // already bridged
    // get wrapper    
    k = kh_get(symbolmap, emu->context->alwrappers, rname);
    if(k==kh_end(emu->context->alwrappers)) {
        printf_log(LOG_INFO, "Warning, no wrapper for %s\n", rname);
        return NULL;
    }
    const char* constname = kh_key(emu->context->alwrappers, k);
    AddOffsetSymbol(emu->context->maplib, symbol, rname);
    return (void*)AddBridge(emu->context->system, kh_value(emu->context->alwrappers, k), symbol, 0, constname);
}

EXPORT void my_alRequestFoldbackStart(x86emu_t *emu, int32_t mode, int32_t count, int32_t length, void* mem, void* cb)
{
    my->alRequestFoldbackStart(mode, count, length, mem, find_Request_Fct(cb));
}

EXPORT void my_alRequestFoldbackStop(x86emu_t* emu)
{
    my->alRequestFoldbackStop();
}

#define CUSTOM_INIT         \
    libname = lib->name;    \
    getMy(lib);

#define CUSTOM_FINI \
    freeMy();

#include "wrappedlib_init.h"

void fillALProcWrapper()
{
    int cnt, ret;
    khint_t k;
    kh_symbolmap_t * symbolmap = kh_init(symbolmap);
    // populates maps...
    cnt = sizeof(openalsymbolmap)/sizeof(map_onesymbol_t);
    for (int i=0; i<cnt; ++i) {
        k = kh_put(symbolmap, symbolmap, openalsymbolmap[i].name, &ret);
        kh_value(symbolmap, k) = openalsymbolmap[i].w;
    }
    // and the my_ symbols map
    cnt = sizeof(MAPNAME(mysymbolmap))/sizeof(map_onesymbol_t);
    for (int i=0; i<cnt; ++i) {
        k = kh_put(symbolmap, symbolmap, openalmysymbolmap[i].name, &ret);
        kh_value(symbolmap, k) = openalmysymbolmap[i].w;
    }
    my_context->alwrappers = symbolmap;
    // fill my_* map
    symbolmap = kh_init(symbolmap);
    cnt = sizeof(MAPNAME(mysymbolmap))/sizeof(map_onesymbol_t);
    for (int i=0; i<cnt; ++i) {
        k = kh_put(symbolmap, symbolmap, openalmysymbolmap[i].name, &ret);
        kh_value(symbolmap, k) = openalmysymbolmap[i].w;
    }
    my_context->almymap = symbolmap;
}
void freeALProcWrapper(box86context_t* context)
{
    if(!context)
        return;
    if(context->alwrappers)
        kh_destroy(symbolmap, context->alwrappers);
    if(context->almymap)
        kh_destroy(symbolmap, context->almymap);
    context->alwrappers = NULL;
    context->almymap = NULL;
}