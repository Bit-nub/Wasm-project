
static int dummy(void)	// Begin of dummy
{
	int rc = 0;

	return rc;
}	// End of dummy
