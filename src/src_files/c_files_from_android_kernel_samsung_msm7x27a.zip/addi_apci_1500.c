#define CONFIG_APCI_1500 1

#define ADDIDATA_DRIVER_NAME	"addi_apci_1500"

#include "addi-data/addi_common.c"

MODULE_AUTHOR("Comedi http://www.comedi.org");
MODULE_DESCRIPTION("Comedi low-level driver");
MODULE_LICENSE("GPL");
