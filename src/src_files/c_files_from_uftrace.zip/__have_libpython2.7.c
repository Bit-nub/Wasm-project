#include <python2.7/Python.h>

int main(void)
{
	Py_Initialize();
	return 0;
}
