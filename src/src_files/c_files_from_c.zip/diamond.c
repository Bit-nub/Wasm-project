#include "diamond.h"
