#include "resistor_color.h"
