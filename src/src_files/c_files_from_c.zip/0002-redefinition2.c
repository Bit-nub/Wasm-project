/*
PATTERN: L1
PATTERN: c:11
*/

void
foo()
{
	L1:
	L2:
	L1:
	return;
}
