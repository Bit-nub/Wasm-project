#include "complex_numbers.h"

complex_t c_add(complex_t a, complex_t b)
{
   // TODO: implement
}

complex_t c_sub(complex_t a, complex_t b)
{
   // TODO: implement
}

complex_t c_mul(complex_t a, complex_t b)
{
   // TODO: implement
}

complex_t c_div(complex_t a, complex_t b)
{
   // TODO: implement
}

double c_abs(complex_t x)
{
   // TODO: implement
}

complex_t c_conjugate(complex_t x)
{
   // TODO: implement
}

double c_real(complex_t x)
{
   // TODO: implement
}

double c_imag(complex_t x)
{
   // TODO: implement
}

complex_t c_exp(complex_t x)
{
   // TODO: implement
}
