/*
PATTERN: x
*/

struct x {
	int x;
	int y;
	int x;
};
