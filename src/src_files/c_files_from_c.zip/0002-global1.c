int x;

int
main()
{
	x = 0;
	return x;
}
