/*
PATTERN: overlap
PATTERN: c:6:
*/

int arr[3] = {[0] = 1, [1] = 2, [0] = 3};

