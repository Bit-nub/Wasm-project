/*
PATTERN: end of struct
PATTERN: c:6:
*/

struct { int a; int b; int c; } x = {1, 2, 3, 4};

