
int
main()
{
	int x;

	x = 0;
	return x;
}
