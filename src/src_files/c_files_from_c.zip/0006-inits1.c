/*
PATTERN: size
PATTERN: c:6:
*/

int x[3] = {1, 2};

