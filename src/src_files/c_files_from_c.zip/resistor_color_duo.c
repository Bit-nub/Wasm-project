#include "resistor_color_duo.h"
