#include "pangram.h"
