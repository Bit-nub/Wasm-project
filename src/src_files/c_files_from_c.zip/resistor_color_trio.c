#include "resistor_color_trio.h"
