/*
PATTERN: c:8
PATTERN: lvalue
*/
int
main()
{
	3++;
}
