/*
PATTERN: undefined
PATTERN: c:9:5
*/

int
main()
{
	x;
}
