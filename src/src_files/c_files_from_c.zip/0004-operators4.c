
int
main()
{
	int x;
	int y;
	
	x = 1;
	y = 1;
	x = y = 0;
	if(x != 0)
		return 1;
	if(y != 0)
		return 1;
	return 0;
}
