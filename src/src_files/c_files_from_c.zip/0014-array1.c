int
main()
{
	int arr[2];
	
	arr[1] = 2;
	if(arr[1] != 2)
		return 1;
	return 0;
}

