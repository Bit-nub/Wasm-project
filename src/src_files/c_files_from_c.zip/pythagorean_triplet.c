#include "pythagorean_triplet.h"
