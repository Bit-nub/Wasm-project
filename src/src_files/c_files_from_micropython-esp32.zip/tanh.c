#include <math.h>

double tanh(double x) {
    return sinh(x) / cosh(x);
}
