#include "lib/oofatfs/ff.h"

DWORD get_fattime(void) {
    return 0;
}
