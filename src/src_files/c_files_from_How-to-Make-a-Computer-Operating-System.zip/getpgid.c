#include <unistd.h>

pid_t getpgid( pid_t pid ) {
    return 0;
}
