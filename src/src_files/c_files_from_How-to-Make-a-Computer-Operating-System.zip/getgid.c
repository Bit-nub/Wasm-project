#include <unistd.h>

gid_t getgid( void ) {
    return 0;
}
