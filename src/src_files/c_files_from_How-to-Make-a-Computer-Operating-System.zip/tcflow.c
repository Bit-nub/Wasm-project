
 

#include <termios.h>

int tcflow( int fd, int action ) {
    return 0;
}
