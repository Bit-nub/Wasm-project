#include <unistd.h>


int chown( const char* path, uid_t owner, gid_t group ) {
    /* TODO */

    printf( "TODO: chown() not yet implemented!\n" );

    return 0;
}
