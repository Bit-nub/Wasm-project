
 

#include <errno.h>
#include <unistd.h>

long fpathconf( int fd, int name ) {
    /* TODO */

    return -1;
}
