//
//  main.c
//  mac_a_mal
//
//  Created by phdphuc on 5/30/17.
//  Copyright © 2017 phdphuc. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
