// SPDX-License-Identifier: GPL-2.0+
/*
 * Samsung A5Y17 and A3Y17 LTE boards based on Exynos 7880 and Exynos 7870 SoCs
 */

#include <common.h>

int exynos_init(void)
{
	return 0;
}
