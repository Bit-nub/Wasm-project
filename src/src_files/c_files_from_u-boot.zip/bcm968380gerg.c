// SPDX-License-Identifier: GPL-2.0+
/*
 * Copyright (C) 2018 Philippe Reynes <philippe.reynes@softathome.com>
 */

#include <common.h>
