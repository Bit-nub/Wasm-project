int main() {
    return !~;
}