int main() {
    int a = 2
    a = a + 4;
    return a;
}