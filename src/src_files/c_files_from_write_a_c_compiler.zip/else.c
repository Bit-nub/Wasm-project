int main() {
    int a = 0;
    if (a)
        return 1;
    else
        return 2;
}