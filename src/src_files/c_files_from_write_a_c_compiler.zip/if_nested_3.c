int main() {
    int a = 0;
    if (1)
        if (2)
            a = 3;
        else
            a = 4;

    return a;
}