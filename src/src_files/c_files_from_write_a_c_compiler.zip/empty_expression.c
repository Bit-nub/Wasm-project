int main() {
    int i = 3;
    ; 
    for (int i = 0; i < 10; i = i + 1)
        ;
    return i;
}