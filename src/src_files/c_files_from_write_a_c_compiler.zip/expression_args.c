int add(int a, int b) {
    return a + b;
}

int main() {
    int sum = add(1 + 2, 4);
    return sum + sum;
}
