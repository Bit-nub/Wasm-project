int main() {
    return foo;
}

int foo = 3;