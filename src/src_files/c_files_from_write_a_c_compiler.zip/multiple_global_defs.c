int foo = 3;

int main() {
    return foo;
}

int foo = 0;