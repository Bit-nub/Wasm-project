int main() {
    for (int i = 2; ))
        int a = 0;
}