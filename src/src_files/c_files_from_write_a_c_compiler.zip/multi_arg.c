int sub_3(int x, int y, int z) {
    return x - y - z;
}

int main() {
    return sub_3(10, 4, 2);
}