int main() {
    while(int a) {
        2;
    }
}