int main() {
    return0;
}