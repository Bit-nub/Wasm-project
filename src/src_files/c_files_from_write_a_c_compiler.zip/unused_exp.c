int main() {
    2 + 2;
    return 0;
}