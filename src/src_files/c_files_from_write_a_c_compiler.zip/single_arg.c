int twice(int x){
    return 2 * x;
}

int main() {
    return twice(3);
}