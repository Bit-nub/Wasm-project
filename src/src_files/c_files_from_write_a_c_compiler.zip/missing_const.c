int main() {
    return !;
}