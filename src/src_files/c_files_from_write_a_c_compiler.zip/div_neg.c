int main() {
    return (-12) / 5;
}