int main() {
    ints a = 1;
    return a;
}