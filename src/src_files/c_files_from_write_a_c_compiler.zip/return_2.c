int main() {
    return 2;
}