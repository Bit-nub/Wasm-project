int a = 3;
int b = 4;

int main() {
    return a * b;
}