int foo = 3;
int bar = foo + 1;

int main() {
    return bar;
}