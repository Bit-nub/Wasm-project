int main() {
    int flag = 0;
    int a = if (flag)
                2;
            else
                3;
    return a;
}