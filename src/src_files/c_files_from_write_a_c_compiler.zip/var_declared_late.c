int main() {
    a = 1 + 2;
    int a;
    return a;
}