int foo = 4;

int main() {
    return foo + 3;
}