int main() {
    do {
        int a = 2;
    } while (a);
    return 0;
}