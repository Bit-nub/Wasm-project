int foo(int a){
    return 3 + a;
}

int main(){
    return foo();
}