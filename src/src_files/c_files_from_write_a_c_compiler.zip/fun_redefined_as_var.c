int foo() {
    return 3;
}

int foo = 4;

int main() {
    return foo;
}