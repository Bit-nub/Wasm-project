int foo(int b);

int main(){
    return foo(3);
}

int foo(int a){
    return a + 1;
}