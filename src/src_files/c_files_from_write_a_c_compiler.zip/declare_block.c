int main() {
    if (5) {
        int i = 0;
        return i;
    }
}