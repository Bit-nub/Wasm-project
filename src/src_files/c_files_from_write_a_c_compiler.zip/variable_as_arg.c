int foo(int x) {
    return x + 1;
}

int main() {
    int a = 1;
    return foo(a);
}
