int main() {
    return 1 < > 3;
}