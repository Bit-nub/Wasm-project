int foo(){
    return 3;
}

int main() {
    return foo();
}

int foo(){
    return 4;
}