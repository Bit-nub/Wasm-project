int foo() {
    return 3;
}

int main() {
    int foo = 5;
    return foo;
}