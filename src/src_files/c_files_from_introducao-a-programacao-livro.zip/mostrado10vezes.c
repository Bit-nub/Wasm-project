#include <stdio.h>

int main() {
    int cont = 1;
    
    while (cont <= 10) {
        printf("Isto sera' mostrado 10 vezes.\n");
        cont++;
    }
    
    return 0;
}

