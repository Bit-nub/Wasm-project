#include <stdio.h>

int main() {
    int x = 5;
    
    if (x)
       printf("Isto sera' mostrado");
       
    if (x - 5)
       printf("Isto nao sera' mostrado");
       
    return 0;
}

