int main() {
	int matriz[20][30];
	int i, j;

	for (i=0; i < 20; i++) 
		for (j = 0; j < 30; j++) 
			scanf("%d", &matriz[i][j]);  

	return 0;
}

