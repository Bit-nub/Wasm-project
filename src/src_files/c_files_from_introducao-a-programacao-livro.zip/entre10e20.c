#include <stdio.h>

int main() {
    int x;
    
    scanf("%d", &x);
    
    if (x > 10 && x < 20)
        printf("x esta' entre 10 e 20.");        

    return 0;
}

