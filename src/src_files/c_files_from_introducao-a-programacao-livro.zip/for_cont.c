#include <stdio.h>

int main() {
    int cont;
    
    for (cont = 1; cont <= 10; cont++)
        printf("Isto sera' mostrado 10 vezes.\n");        
        
    return 0;
}

