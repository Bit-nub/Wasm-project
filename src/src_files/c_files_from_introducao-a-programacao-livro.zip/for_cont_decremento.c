#include <stdio.h>

int main() {
    int cont;
    
    for (cont = 10; cont > 0; cont--)
        printf("Valor de cont: %i\n", cont);
        
    return 0;
}
