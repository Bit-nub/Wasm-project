#include <stdio.h>

int main() {
    int x;
    
    scanf("%d", &x);
    
    if (x < 20)
       printf("O valor de x e' menor que 20.");
       
    return 0;   
}
