/* Hello World program */

#include<stdio.h>   // <1> 

main()
{
    printf("Hello World");   // <2> imprime "Hello Word" na tela.
}

