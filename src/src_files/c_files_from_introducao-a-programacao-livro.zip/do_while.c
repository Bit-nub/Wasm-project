#include <stdio.h>

int main() {
    int cont = 1;
    
    do {
       printf("Isto sera' mostrado 10 vezes.\n");
       cont++;
    } while (cont <= 10);
    
    return 0;
}
