#include <stdio.h>

int main() {
    int cont;
    
    for (cont = 1; ; cont++)
        printf("Laco infinito.\n");        
        
    return 0;
}

