/*
 * This file is here to ensure that the library has an object file created for native test builds
 */
int __crsf_dummy;
