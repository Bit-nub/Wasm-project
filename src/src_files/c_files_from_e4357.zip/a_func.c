#include<stdio.h>
void a_func(void)
{
	printf("I am in %s\n", __FUNCTION__);
}
