/*************************************************************************
    > File Name: 1.c
    > Author: GatieMe
    > Mail: gatieme@163.com
    > Created Time: Sun 15 Oct 2017 11:53:53 AM CST
 ************************************************************************/

#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[])
{
	return EXIT_SUCCESS;
}


