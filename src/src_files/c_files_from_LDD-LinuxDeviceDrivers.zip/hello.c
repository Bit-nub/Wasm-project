#include <stdio.h>
#include <stdlib.h>


int main(int argc, char **argv)
{


  printf("Hello Reader,Congradulations!!!\n");
  return(0);

}
