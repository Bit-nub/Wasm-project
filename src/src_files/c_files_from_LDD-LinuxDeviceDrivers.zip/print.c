/*************************************************************************
    > File Name: 1.c
    > Author: GatieMe
    > Mail: gatieme@163.com
    > Created Time: Sat 14 Oct 2017 10:09:04 AM CST
 ************************************************************************/

#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[])
{
	printf("=======\n");
	return EXIT_SUCCESS;
}


