
int _adjust_fdiv = 0;

/* EOF */
