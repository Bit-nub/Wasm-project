
#define USE_RTL_BITMAP64

#include "bitmap.c"
