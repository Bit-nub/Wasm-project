/*
 *  entities.c
 *  dEngine
 *
 *  Created by fabien sanglard on 11/09/09.
 *
 */

#include "entities.h"

//entities_t entities;