/*
 *  config.c
 *  dEngine
 *
 *  Created by fabien sanglard on 13/09/09.
 *
 */

#include "config.h"

