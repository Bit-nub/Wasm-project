
/*
 *  filesystem.c
 *  dEngine
 *
 *  Created by fabien sanglard on 10/08/09.
 *
 */

#include "filesystem.h"



//#include <sys/stat.h>
char fs_gamedir[ MAX_OSPATH ];



void FS_InitFilesystem( void )
{
	char *p;
	p = getenv("CWD");
	sprintf( fs_gamedir, "%s", p );
	printf("[Filesystem] Base directory initialized.\n");
	//printf("[Filesystem] Base directory = '%s'.\n",fs_gamedir);
}


char *FS_Gamedir( void )
{
	return fs_gamedir;
}


filehandle_t* FS_OpenFile( const char *filename, char* mode  )
{
	char			netpath[ MAX_OSPATH ];
	filehandle_t	*hFile;
	const char		*pathBase;
	
	FILE*	fd;
	int		pos;
	int		end;
	
	memset(netpath,0,MAX_OSPATH);
	
	pathBase = FS_Gamedir();
		
	sprintf( netpath, "%s/%s", pathBase, filename );
	
	//printf("Absolute path: '%s'",netpath);
	
	// high performance file mapping path, avoiding stdio
	fd = fopen( netpath, mode );
	if ( !fd  ) {
		printf("Could not open file'%s'\n",netpath);
		return NULL;
	}
	
	
	hFile = (filehandle_t*) calloc(1, sizeof( filehandle_t ) );
	memset( hFile, 0, sizeof( filehandle_t ) );
	
	
	pos = ftell (fd);
	fseek (fd, 0, SEEK_END);
	end = ftell (fd);
	fseek (fd, pos, SEEK_SET);
	hFile->filesize = end;
	
	//if (!strcmp("data/scenes/techDemo.scene", filename))
	//{
	//	printf("techDemo.scene filesize = %d",hFile->filesize);
	//}
	
	hFile->filedata = calloc( hFile->filesize,sizeof(char) );
	
	fread(hFile->filedata, sizeof(char),hFile->filesize, fd);
	
	hFile->ptrStart =  hFile->ptrCurrent = (PW8)hFile->filedata;
	hFile->ptrEnd =  (PW8)hFile->filedata + hFile->filesize;
	hFile->bLoaded = 1;
	
	//printf("Closing file: '%s'\n",netpath);
	
	
	fclose( fd );
	return hFile;
}

SW32 FS_ReadFile( void *buffer, W32 size, W32 count, filehandle_t *fhandle )
{		
	W8	*buf = (PW8)buffer;
	W32 i;
	
	if( (size * count) > (fhandle->ptrEnd - fhandle->ptrCurrent) )
	{
		SW32 read;
		
		read = (fhandle->ptrEnd - fhandle->ptrCurrent);
		
		for( i = 0 ; i < (fhandle->ptrEnd - fhandle->ptrCurrent) ; ++i )
		{
			buf[ i ] = fhandle->ptrCurrent[ i ];
		}
		
		fhandle->ptrCurrent = fhandle->ptrEnd;
		
		return( read );
	}
	else
	{
		for( i = 0 ; i < (size * count) ; ++i, fhandle->ptrCurrent++ )
		{
			buf[ i ] = *fhandle->ptrCurrent;
		}
		
		return( (size * count) / size );
	}
	
	/* should never get here */
	return -1;
}

SW32 FS_GetFileSize( filehandle_t *fhandle )
{
	return fhandle->filesize;
}


void FS_CloseFile( filehandle_t *fhandle )
{
	if( fhandle->filedata )
	{
		
		free( fhandle->filedata );
		fhandle->filedata = NULL;
	}
	
	free( fhandle );
}


W32 FS_FileSeek( filehandle_t *fhandle, SW32 offset, W32 origin )
{
	switch( origin )
	{
		case SEEK_SET:
			if( offset < 0 || offset > fhandle->filesize )
			{
				return 1;
			}
			
			fhandle->ptrCurrent = fhandle->ptrStart + offset;
			break;
			
		case SEEK_END:
			if( offset > 0 )
			{
				return 1;
			}
			
			// offset is negative 
			if( (fhandle->filesize + offset) < 0  )
			{
				return 1;
			}
			
			// offset is negative 
			fhandle->ptrCurrent = fhandle->ptrEnd + offset;
			break;
			
		case SEEK_CUR:
			if( offset < 0 )
			{
				// offset is negative
				if( ((fhandle->ptrCurrent - fhandle->ptrStart) + offset) < 0 )
				{
					return 1;
				}
			}
			
			if( offset > 0 )
			{
				if( offset > (fhandle->ptrEnd - fhandle->ptrCurrent) )
				{
					return 1;
				}
			}
			
			fhandle->ptrCurrent += offset;
			break;
			
		default:
			return 1;
	}
	
	return 0;
}

SW32 FS_FileTell( filehandle_t *fhandle )
{
	return( fhandle->ptrCurrent - fhandle->ptrStart );
}

/*
 -----------------------------------------------------------------------------
 Function: FS_GetLoadedFilePointer() -Get file pointer.
 
 Parameters: 
 filestream -[in] Target file handle.
 origin -[in] Pointer position
 SEEK_SET -Beginning of file.
 SEEK_CUR -Current position of file pointer.
 SEEK_END -End of file.
 
 Returns: File pointer on success, otherwise NULL.
 
 Notes: 
 -----------------------------------------------------------------------------
 */
void *FS_GetLoadedFilePointer( filehandle_t *fhandle, W32 origin )
{
	switch( origin )
	{
		case SEEK_SET:
			return( (void *)fhandle->ptrStart );
			
		case SEEK_END:
			return( (void *)fhandle->ptrEnd );
			
		case SEEK_CUR:
			return( (void *)fhandle->ptrCurrent );
	}
	
	return NULL;
}




void FS_StripExtension( const char *in, char *out )
{
	while( *in && *in != '.' )
	{
		*out++ = *in++;
	}
	
	*out = '\0'; // NUL-terminate string.
}

char *FS_FileExtension( const char *in )
{
	static char exten[ 8 ];
	char*		j;
	char*       i;
	
	i = (char*)in + strlen(in);
	j = (char*)exten + 7;
	
	exten[7] = '\0';
	
	while(*i != '.')
	{
		j--;
		i--;
		*j = *i;
		//in--;
	}
	j++;
	
	//exten[7] = '\0'; // NUL-terminate string.
	
	return j;
}

void FS_DirectoryPath(  char *in, char *out )
{
	char *s;
	
	s = in + strlen( in ) ;
	out += strlen( in ) ;
	
	while( s != in && *s != '/' && *s != '\\')
	{
		s--;
		out--;
	}
	
	while( s != in-1)
		*out-- = *s--;
}

char* FS_GetExtensionAddress(char* string)
{
	char* extension;
	
	extension = &string[strlen(string)-1];
	
	while(*extension != '.' && extension != string)
		extension--;
	
	return (extension+1);
}

